let garrafas = [];
let gotas = [];
let larguraCanvas = 600;
let alturaCanvas = 400;
let numGarrafas = 2;
let capacidadeGarrafa = 100;

function setup() {
  createCanvas(larguraCanvas, alturaCanvas);
  // Criar as garrafas
  let espacamento = larguraCanvas / (numGarrafas + 1);
  for (let i = 0; i < numGarrafas; i++) {
    garrafas.push(new Garrafa(espacamento * (i + 1), alturaCanvas - 60));
  }
}

function draw() {
  background(150, 200, 255);

  // Desenhar o fundo (simplificado)
  fill(100);
  rect(0, alturaCanvas * 0.7, larguraCanvas * 0.5, alturaCanvas * 0.3); // "Campo"
  fill(120);
  rect(larguraCanvas * 0.5, alturaCanvas * 0.6, larguraCanvas * 0.5, alturaCanvas * 0.4); // "Cidade"

  // Mostrar e mover as garrafas
  for (let garrafa of garrafas) {
    garrafa.mostrar();
    garrafa.mover();
    garrafa.mostrarNivel();
  }

  // Criar novas gotas
  if (random(1) < 0.03) {
    gotas.push(new Gota());
  }

  // Mostrar e atualizar as gotas
  for (let i = gotas.length - 1; i >= 0; i--) {
    gotas[i].mostrar();
    gotas[i].cair();
    for (let j = 0; j < garrafas.length; j++) {
      if (gotas[i].atingiu(garrafas[j])) {
        garrafas[j].encher();
        gotas.splice(i, 1);
        break; // Uma gota só pode encher uma garrafa por vez
      }
    }
    if (gotas[i].y > alturaCanvas) {
      gotas.splice(i, 1);
    }
  }
}

class Garrafa {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.largura = 30;
    this.altura = 50;
    this.nivel = 0;
  }

  mostrar() {
    fill(200);
    rectMode(CENTER);
    rect(this.x, this.y, this.largura, this.altura);
    // Desenhar o "conteúdo" da garrafa
    fill(100, 180, 255);
    rect(this.x, this.y + this.altura / 2 - map(this.nivel, 0, capacidadeGarrafa, 0, this.altura), this.largura, map(this.nivel, 0, capacidadeGarrafa, 0, this.altura));
    rectMode(CORNER);
  }

  mover() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += 5;
    }
    this.x = constrain(this.x, this.largura / 2, larguraCanvas - this.largura / 2);
  }

  encher() {
    this.nivel += 10; // Aumenta o nível de água
    this.nivel = min(this.nivel, capacidadeGarrafa);
  }

  mostrarNivel() {
    fill(0);
    textSize(12);
    textAlign(CENTER);
    text(this.nivel + '/' + capacidadeGarrafa, this.x, this.y + this.altura + 15);
    textAlign(LEFT);
  }
}

class Gota {
  constructor() {
    this.x = random(larguraCanvas);
    this.y = random(-50, -10);
    this.velocidade = random(2, 5);
    this.raio = random(5, 10);
    this.tipo = random() > 0.5 ? 'campo' : 'cidade';
  }

  cair() {
    this.y += this.velocidade;
  }

  mostrar() {
    noStroke();
    if (this.tipo === 'campo') {
      fill(100, 180, 255); // Cor para gotas do campo
      ellipse(this.x, this.y, this.raio * 2, this.raio * 2);
    } else {
      fill(180, 220, 255); // Cor para gotas da cidade
      rect(this.x - this.raio, this.y - this.raio, this.raio * 2, this.raio * 2);
    }
  }

  atingiu(garrafa) {
    let d = dist(this.x, this.y, garrafa.x, garrafa.y);
    return d < this.raio + garrafa.largura / 2;
  }
}